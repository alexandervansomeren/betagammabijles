<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<title>Noppes doc</title>
</head>
<body>

<h1>Noppes</h1>

<p>Het formulier waar u mee werkt is een testformulier. De knoppen werken niet echt.
Annuleer en submit leiden beiden naar deze tekst.<br />
Klik de back-knop om terug te gaan of <br />
Ga terug naar de <a href="../">index</a></p>

<p>Hieronder een overzicht van geposte waarden:</p>

<p><?php print_r($_POST); ?></p>

</body>
</html>