<pre>
<?php
var_dump($_GET);
?>
</pre>
