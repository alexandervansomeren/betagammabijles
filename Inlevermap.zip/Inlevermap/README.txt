- URL: http://webdb.science.uva.nl/webdb13BG2

- Login (heeft nog geen functionaliteit):
	Username: Salty
	Password: Pepper

- Bron stuk code voor beveiligde mail:
		http://www.w3schools.com/php/php_secure_mail.asp

- Namen/studentennummers:

Tim Leunissen - 10191828
Bastiaan Nachtegaal - 6153216
Alexander van Someren - 10169547
Emma Boumans - 10194851