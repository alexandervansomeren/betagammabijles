-- MySQL dump 10.13  Distrib 5.1.61, for redhat-linux-gnu (x86_64)
--
-- Host: localhost    Database: webdb13BG2
-- ------------------------------------------------------
-- Server version	5.1.61

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adress_data`
--

DROP TABLE IF EXISTS `adress_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adress_data` (
  `user_id` int(11) NOT NULL,
  `city` varchar(63) CHARACTER SET utf8 NOT NULL,
  `street` varchar(127) CHARACTER SET utf8 NOT NULL,
  `postal` smallint(6) NOT NULL,
  `postal_extra` varchar(4) CHARACTER SET utf8 NOT NULL,
  `streetnumber` varchar(31) CHARACTER SET utf8 NOT NULL,
  KEY `city` (`city`,`postal`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Lelijke tabel';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adress_data`
--

LOCK TABLES `adress_data` WRITE;
/*!40000 ALTER TABLE `adress_data` DISABLE KEYS */;
INSERT INTO `adress_data` VALUES (10,'Amsterdam','asdf',1234,'AB','12A'),(6,'Amsterdam','Kinkerstraat',1234,'AB','81'),(2,'Hall','Lendeweg',1055,'DJ','10'),(4,'Leiden','Boerhaavelaan',2334,'AB','28'),(5,'Amsterdam','Zuiderzeeweg',1234,'AB','40'),(3,'Amsterdam','Kalverstraat',1234,'AB','12'),(25,'Amsterdam','Rusland',1111,'GF','2'),(26,'Utrecht','Oudegracht',3576,'AA','223'),(27,'Amsterdam','Prinsengracht',1122,'ZC','20'),(28,'Diemen','Rode Kruislaan',1111,'XC','1301C'),(29,'Amsterdam','Keizersgracht',1014,'BJ','310'),(30,'Diemen','Rode Kruislaan',1111,'XA','1111D'),(31,'Diemen','Rode Kruislaan',1111,'XA','1118D'),(32,'Diemen','Rode Kruislaan',1111,'XD','1415C'),(33,'Diemen','Rode Kruislaan',1111,'XA','1119E'),(34,'Diemen','Rode Kruislaan',1111,'XB','1212C'),(35,'Diemen','Rode Kruislaan',1111,'XB','1220A'),(36,'Diemen','Rode Kruislaan',1111,'XB','1211A'),(37,'Diemen','Rode Kruislaan',1111,'XB','1201A'),(38,'Diemen','Rode Kruislaan',1111,'XB','1216B'),(39,'Diemen','Rode Kruislaan',1111,'XC','1316C'),(40,'Diemen','Rode Kruislaan',1111,'XD','1401A'),(41,'Diemen','Rode Kruislaan',1111,'XE','1511E'),(42,'Diemen','Rode Kruislaan',1111,'XB','1213A'),(43,'Diemen','Rode Kruislaan',1111,'XA','1111E'),(44,'Diemen','Rode Kruislaan',1111,'XA','1118A'),(45,'Diemen','Rode Kruislaan',1111,'XA','1112A'),(46,'Diemen','Rode Kruislaan',1111,'XB','1215A'),(47,'Amsterdam','Leidseplein',1233,'AB','1'),(48,'Diemen','Rode Kruislaan',1111,'XB','1213C'),(49,'Diemen','Rode Kruislaan',1111,'XA','1111A'),(50,'Amsterdam','Sciencepark',1024,'XX','409'),(51,'Amsterdam','van tuyll van serooskerkenweg',1076,'AB','21'),(52,'Diemen','Rode Kruislaan',1111,'XB','1216A'),(53,'Diemen','Rode Kruislaan',1111,'XE','1501E'),(54,'Diemen','Rode Kruislaan',1111,'XB','1208A'),(55,'Diemen','Rode Kruislaan',1111,'XA','1112C'),(56,'Diemen','Rode Kruislaan',1111,'XC','1308A'),(57,'Diemen','Rode Kruislaan',1111,'XB','1213E'),(58,'Amsterdam','Prinsengracht',1011,'AB','221'),(59,'Amsterdam','Rokin',1091,'AC','32'),(60,'Amsterdam','Spuistraat',1094,'CD','23'),(61,'Amsterdam','Roetersstraat',1000,'XA','10'),(62,'Amsterdam','Spuistraat',1043,'XD','54'),(63,'Amsterdam','Prinseneiland',1094,'AG','2'),(64,'Diemen','Rode Kruislaan',1111,'XC','1318D'),(66,'Amsterdam','Driehoekstraat',1093,'AC','8'),(67,'Leiden','Willem de Zwijgerlaan',2335,'KL','2'),(68,'Arnhem','Van Goghstraat',1001,'AW','2'),(74,'Den Haag','Plein',2335,'KL','1'),(73,'Leiden','Marienpoelstraat',2334,'CX','37'),(75,'Delft','Kerklaan',2331,'AC','17'),(76,'Leiden','Marienpoelstraat',2334,'CA','41'),(77,'Amsterdam','Prinsengracht',1013,'EE','14'),(78,'','',0,'',''),(79,'Asmterdam','Keizersgracht',1013,'BJ','103'),(80,'Amsterdam','Overtoom',1234,'AB','23'),(78,'','',0,'',''),(78,'','',0,'','');
/*!40000 ALTER TABLE `adress_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_code`
--

DROP TABLE IF EXISTS `course_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_code` (
  `course_code` int(11) NOT NULL,
  `course_id` smallint(6) NOT NULL,
  `course_difficulty` smallint(6) NOT NULL,
  PRIMARY KEY (`course_code`),
  KEY `course_id` (`course_id`,`course_difficulty`),
  KEY `course_code` (`course_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Course_code is combinatie course_id en course_difficulty';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_code`
--

LOCK TABLES `course_code` WRITE;
/*!40000 ALTER TABLE `course_code` DISABLE KEYS */;
INSERT INTO `course_code` VALUES (101,1,1),(102,1,2),(103,1,3),(104,1,4),(105,1,5),(106,1,6),(107,1,7),(108,1,8),(109,1,9),(110,1,10),(111,1,11),(201,2,1),(202,2,2),(203,2,3),(204,2,4),(205,2,5),(206,2,6),(207,2,7),(208,2,8),(209,2,9),(210,2,10),(211,2,11),(301,3,1),(302,3,2),(303,3,3),(304,3,4),(305,3,5),(306,3,6),(307,3,7),(308,3,8),(309,3,9),(310,3,10),(311,3,11),(401,4,1),(402,4,2),(403,4,3),(404,4,4),(405,4,5),(406,4,6),(407,4,7),(408,4,8),(409,4,9),(410,4,10),(411,4,11),(501,5,1),(502,5,2),(503,5,3),(504,5,4),(505,5,5),(506,5,6),(507,5,7),(508,5,8),(509,5,9),(510,5,10),(511,5,11),(601,6,1),(602,6,2),(603,6,3),(604,6,4),(605,6,5),(606,6,6),(607,6,7),(608,6,8),(609,6,9),(610,6,10),(611,6,11),(701,7,1),(702,7,2),(703,7,3),(704,7,4),(705,7,5),(706,7,6),(707,7,7),(708,7,8),(709,7,9),(710,7,10),(711,7,11),(801,8,1),(802,8,2),(803,8,3),(804,8,4),(805,8,5),(806,8,6),(807,8,7),(808,8,8),(809,8,9),(810,8,10),(811,8,11),(901,9,1),(902,9,2),(903,9,3),(904,9,4),(905,9,5),(906,9,6),(907,9,7),(908,9,8),(909,9,9),(910,9,10),(911,9,11),(1001,10,1),(1002,10,2),(1003,10,3),(1004,10,4),(1005,10,5),(1006,10,6),(1007,10,7),(1008,10,8),(1009,10,9),(1010,10,10),(1011,10,11),(1101,11,1),(1102,11,2),(1103,11,3),(1104,11,4),(1105,11,5),(1106,11,6),(1107,11,7),(1108,11,8),(1109,11,9),(1110,11,10),(1111,11,11),(1201,12,1),(1202,12,2),(1203,12,3),(1204,12,4),(1205,12,5),(1206,12,6),(1207,12,7),(1208,12,8),(1209,12,9),(1210,12,10),(1211,12,11),(1301,13,1),(1302,13,2),(1303,13,3),(1304,13,4),(1305,13,5),(1306,13,6),(1307,13,7),(1308,13,8),(1309,13,9),(1310,13,10),(1311,13,11),(1401,14,1),(1402,14,2),(1403,14,3),(1404,14,4),(1405,14,5),(1406,14,6),(1407,14,7),(1408,14,8),(1409,14,9),(1410,14,10),(1411,14,11),(1501,15,1),(1502,15,2),(1503,15,3),(1504,15,4),(1505,15,5),(1506,15,6),(1507,15,7),(1508,15,8),(1509,15,9),(1510,15,10),(1511,15,11),(1601,16,1),(1602,16,2),(1603,16,3),(1604,16,4),(1605,16,5),(1606,16,6),(1607,16,7),(1608,16,8),(1609,16,9),(1610,16,10),(1611,16,11),(1701,17,1),(1702,17,2),(1703,17,3),(1704,17,4),(1705,17,5),(1706,17,6),(1707,17,7),(1708,17,8),(1709,17,9),(1710,17,10),(1711,17,11),(1801,18,1),(1802,18,2),(1803,18,3),(1804,18,4),(1805,18,5),(1806,18,6),(1807,18,7),(1808,18,8),(1809,18,9),(1810,18,10),(1811,18,11),(1901,19,1),(1902,19,2),(1903,19,3),(1904,19,4),(1905,19,5),(1906,19,6),(1907,19,7),(1908,19,8),(1909,19,9),(1910,19,10),(1911,19,11),(2001,20,1),(2002,20,2),(2003,20,3),(2004,20,4),(2005,20,5),(2006,20,6),(2007,20,7),(2008,20,8),(2009,20,9),(2010,20,10),(2011,20,11),(2101,21,1),(2102,21,2),(2103,21,3),(2104,21,4),(2105,21,5),(2106,21,6),(2107,21,7),(2108,21,8),(2109,21,9),(2110,21,10),(2111,21,11),(2201,22,1),(2202,22,2),(2203,22,3),(2204,22,4),(2205,22,5),(2206,22,6),(2207,22,7),(2208,22,8),(2209,22,9),(2210,22,10),(2211,22,11),(2301,23,1),(2302,23,2),(2303,23,3),(2304,23,4),(2305,23,5),(2306,23,6),(2307,23,7),(2308,23,8),(2309,23,9),(2310,23,10),(2311,23,11),(2401,24,1),(2402,24,2),(2403,24,3),(2404,24,4),(2405,24,5),(2406,24,6),(2407,24,7),(2408,24,8),(2409,24,9),(2410,24,10),(2411,24,11),(2501,25,1),(2502,25,2),(2503,25,3),(2504,25,4),(2505,25,5),(2506,25,6),(2507,25,7),(2508,25,8),(2509,25,9),(2510,25,10),(2511,25,11),(2601,26,1),(2602,26,2),(2603,26,3),(2604,26,4),(2605,26,5),(2606,26,6),(2607,26,7),(2608,26,8),(2609,26,9),(2610,26,10),(2611,26,11),(2701,27,1),(2702,27,2),(2703,27,3),(2704,27,4),(2705,27,5),(2706,27,6),(2707,27,7),(2708,27,8),(2709,27,9),(2710,27,10),(2711,27,11),(2801,28,1),(2802,28,2),(2803,28,3),(2804,28,4),(2805,28,5),(2806,28,6),(2807,28,7),(2808,28,8),(2809,28,9),(2810,28,10),(2811,28,11),(2901,29,1),(2902,29,2),(2903,29,3),(2904,29,4),(2905,29,5),(2906,29,6),(2907,29,7),(2908,29,8),(2909,29,9),(2910,29,10),(2911,29,11),(3001,30,1),(3002,30,2),(3003,30,3),(3004,30,4),(3005,30,5),(3006,30,6),(3007,30,7),(3008,30,8),(3009,30,9),(3010,30,10),(3011,30,11),(3101,31,1),(3102,31,2),(3103,31,3),(3104,31,4),(3105,31,5),(3106,31,6),(3107,31,7),(3108,31,8),(3109,31,9),(3110,31,10),(3111,31,11),(3201,32,1),(3202,32,2),(3203,32,3),(3204,32,4),(3205,32,5),(3206,32,6),(3207,32,7),(3208,32,8),(3209,32,9),(3210,32,10),(3211,32,11);
/*!40000 ALTER TABLE `course_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_difficulty`
--

DROP TABLE IF EXISTS `course_difficulty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_difficulty` (
  `difficulty_name` varchar(127) CHARACTER SET utf8 NOT NULL,
  `difficulty_id` int(11) NOT NULL,
  UNIQUE KEY `difficulty_int` (`difficulty_id`),
  UNIQUE KEY `difficulty_name_2` (`difficulty_name`),
  KEY `difficulty_name` (`difficulty_name`,`difficulty_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='In deze tabel wordt de moeilijkheidsgraad gekoppeld aan een ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_difficulty`
--

LOCK TABLES `course_difficulty` WRITE;
/*!40000 ALTER TABLE `course_difficulty` DISABLE KEYS */;
INSERT INTO `course_difficulty` VALUES ('Basic',1),('Basisschool',2),('HAVO-bovenbouw',9),('HAVO-onderbouw',8),('PRO',3),('VMBO-BBL',4),('VMBO-GL',6),('VMBO-KBL',5),('VMBO-T',7),('VWO-bovenbouw',11),('VWO-onderbouw',10);
/*!40000 ALTER TABLE `course_difficulty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_id`
--

DROP TABLE IF EXISTS `course_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_id` (
  `course_name` varchar(127) CHARACTER SET utf8 NOT NULL,
  `course_id` smallint(6) NOT NULL,
  UNIQUE KEY `subject_name_2` (`course_name`,`course_id`),
  KEY `subject_name` (`course_name`,`course_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='In deze tabel wordt de vaknaam gekoppeld aan een nummer';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_id`
--

LOCK TABLES `course_id` WRITE;
/*!40000 ALTER TABLE `course_id` DISABLE KEYS */;
INSERT INTO `course_id` VALUES ('Aardrijkskunde',1),('ANW',19),('Arabisch',25),('Biologie',2),('Culturele Kunstzinnige Vorming',32),('Duits',11),('Economie',12),('Engels',4),('Filosofie',30),('Frans',10),('Fries',20),('Geschiedenis',28),('Grieks',14),('Informatica',27),('Italiaans',22),('Kunst Algemeen',31),('Latijn',13),('M &amp O',15),('Maatschappijwetenschappen',29),('MaL',16),('Muziek',17),('Natuurkunde',18),('Nederlands',5),('NLT',26),('Russisch',23),('Scheikunde',3),('Spaans',21),('Turks',24),('Wiskunde A',6),('Wiskunde B',7),('Wiskunde C',8),('Wiskunde D',9);
/*!40000 ALTER TABLE `course_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_user`
--

DROP TABLE IF EXISTS `course_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_user` (
  `course_code` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  KEY `course_code` (`course_code`),
  KEY `course_code_2` (`course_code`),
  KEY `course_code_3` (`course_code`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COMMENT='Region kan uitgebouwd worden met tabel';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_user`
--

LOCK TABLES `course_user` WRITE;
/*!40000 ALTER TABLE `course_user` DISABLE KEYS */;
INSERT INTO `course_user` VALUES (101,2),(1111,3),(106,3),(106,4),(103,5),(1408,3),(2805,3),(104,6),(107,10),(311,54),(211,54),(111,54),(2811,53),(711,53),(211,53),(111,53),(1411,52),(1911,52),(2911,52),(111,55),(1211,55),(2311,55),(1011,56),(2111,56),(2211,56),(1311,57),(1811,57),(2311,57),(711,58),(1211,58),(2311,58),(611,60),(711,60),(811,60),(911,60),(1811,60),(911,61),(1811,61),(2711,61),(1711,62),(2411,62),(211,66),(611,66),(411,67),(511,67),(811,73),(911,73),(211,74),(311,74),(102,75),(202,75),(302,75),(801,76),(1301,76),(201,77),(501,77),(1201,77),(1401,77),(101,78),(301,78),(501,78),(701,78),(901,78),(1101,78),(401,79),(1501,79),(1901,79),(501,80),(101,78),(101,78),(101,0),(101,0),(101,250),(101,250);
/*!40000 ALTER TABLE `course_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_data`
--

DROP TABLE IF EXISTS `user_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_data` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Genummerde unieke user_id',
  `username` varchar(31) CHARACTER SET utf8 NOT NULL COMMENT 'Gebruikersnaam ingevuld door user in reg.form.',
  `password` char(255) CHARACTER SET utf8 NOT NULL COMMENT 'Wachtwoord na hashing.',
  `user_type` tinyint(4) NOT NULL,
  `salt` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  KEY `username_2` (`username`),
  KEY `username_3` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=81 DEFAULT CHARSET=latin1 COMMENT='In deze tabel wordt de user_data opgeslagen. De primary key ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_data`
--

LOCK TABLES `user_data` WRITE;
/*!40000 ALTER TABLE `user_data` DISABLE KEYS */;
INSERT INTO `user_data` VALUES (1,'Emma123','1111',1,''),(2,'Emma1243','1111',1,''),(3,'alexandervansomeren','pw28321',1,''),(4,'spacekees','tralili',1,''),(5,'desuperuser','lois',1,''),(6,'lauraa-lauu','geheim',1,''),(7,'EmmaTEST',' Geheim!',2,''),(8,'usernaampje','geheim',1,''),(9,'usernaampje2','geheim',1,''),(10,'Emmam','Emaowut',1,''),(63,'OpenBijlesGever','b89617bed87de2357dd8e3c6a2f07b35554681fd',1,'e9c9b773d7bfbe0d8c0cdc2fb71d067e'),(62,'HalleBalle','02efd9c8f9dcf3191f7a07a14bc886edfda50eab',1,'370b37c7c541b8b79443e4e2ff15ff3d'),(21,'alexsomer','16da7bc06a089eb09703f655c7d170b62676f6d5',1,'8209884f24c895621ab7bd18e252d921'),(22,'alexsomer2','c93343504be92e8fb170479d56eadfb70794b4f4',1,'0d5ffb59286f39fd922b08e27717cfe6'),(23,'alexsomer3','8802d284a6015ebbb0e879deb3f65dc033470544',1,'eece8c59c3992fa3b48cc845a8168e42'),(24,'alexsomer4beheer','',3,''),(61,'GeaBea','707fe7be06fd4bac41fc4cab00e08a6802266021',1,'3da25f257b8fd7551ee27fbff94093f4'),(60,'Alexander2','b4e91390a0a12711e7951045dbc1f5c463a7f1b6',1,'f17d839942e5e3f2de69768cece796a0'),(59,'EmmaAccount2','aa6cd0da344765416f316116d48e55d420a7a487',2,'7420ec6fb1ffdd09170adc801947cd9d'),(43,'Salty','469af9fb680229926e8f355dae1bc913a1058ff8',2,'bb688045ebc61c8bf3e738cbe5308c91'),(58,'KoningMetBaard','7e0815b87afea769777a6940fbdd9f243e260dc3',1,'6f43b8b9a6693cc4903a4b64700da7fb'),(57,'Willem123','cffc21e8ea25fdf770d0281cac5c912f4282051a',1,'4b39ae6acc0feddb4b78e7ff0cf67178'),(56,'Hoefijzer','0d669d6fef1bb9b6782bf63abd55d012700f7c1d',1,'501a0533fde858c4c6797cce56aad1e9'),(55,'Froukje00','955418982aa865cb42f585e48ca76180cb290416',1,'d16d4ddc28c3dd92bcc7589a6ef749d0'),(54,'Francine','e44c58b73c2fb64a4c39be783a9ae64ad1119074',1,'cf90c321a87193c21fe23902285b29df'),(53,'FiekeWieke','3f230b4e85298d404b90d1dce04befa852cd5c0d',1,'60236446bffa467da252584eb0c57cf6'),(51,'Lars','07b7d696f399e6d4e4761459427e4cdc38d42a49',1,'dd5c0702b66979f4a06e77cf513e1e1e'),(52,'Bierbierbier','6931eabcc6b68d33b00c6fa70958faa4a042f278',2,'ec60f0d8946fe4d62e114587d9990580'),(64,'KabouterPlop','14f1c17f70254af4c7a337d1f7f6df1b36d9f73f',1,'f1471019d4d2a740c7ef5ba4826d18ab'),(66,'Kromhout','a81c28b47ff1733e1cb07701f23c98730051e441',1,'8368a0fa714639066c63d50919bab7c5'),(67,'AnnekePanneke','88fb28901778051a706bd36b8d127aa6b075fb60',1,'fd6ada57d17c0a5808e7071a13a3d6ee'),(68,'Boomstam','25c5fc6ba94f57ed36642a6812cbf632e9da6418',1,'41feaca5df25cc47fa84b107b20522d3'),(74,'Auwoiut','3d55325797ab3308e4814756234f24cb08eebe6e',1,'0dcf7f075994909f5fa5b27ec299e2de'),(73,'woeut','b311339bbf01dd6cff14dad4425f5e0b0ce140cc',1,'4183513ed039430c8b70fce6468eacb6'),(75,'Bert','d3aa6e1af4a3aeb704c76ec8937573dc8b9ae909',1,'723af932211f17f791a11faaac9ae653'),(76,'Griekje','2b77c17ae6cb895fb5e65ef3317ed4f690eb09c1',1,'4db335477bf6cca081eb03573f564a79'),(77,'alexander','be85e88566e300ed8e71b55dc58843637863ef2d',1,'671c5ccc4f43cfe88c2f8b94ead6c3d4'),(78,'','7c96d80335b7d452c38b02037bd5950cec0ec5d2',1,'20e48795500239e8ed23d10406073bf3'),(79,'username1234','342cfdbc96cea2697ca8b3555b7398256c573df4',1,'13fb94c7b6d3bbd0d20a189d345a5c0a'),(80,'Ilse','5b0371d6b624f8a9da5839e1b2a43296f4c3aba6',1,'db457e337d5ea7b9dbec64b2daf6ea3a');
/*!40000 ALTER TABLE `user_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_personal_data`
--

DROP TABLE IF EXISTS `user_personal_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_personal_data` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(31) CHARACTER SET utf8 NOT NULL,
  `middle_name` varchar(31) CHARACTER SET utf8 DEFAULT NULL COMMENT 'Tussenvoegsel',
  `last_name` varchar(63) CHARACTER SET utf8 NOT NULL,
  `gender` tinyint(1) DEFAULT NULL,
  `emailadress` varchar(255) CHARACTER SET utf8 NOT NULL,
  `phone_1` varchar(31) CHARACTER SET utf8 DEFAULT NULL,
  `phone_2` varchar(31) CHARACTER SET utf8 DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `about_me` text CHARACTER SET utf8,
  `last_login` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `gender` (`gender`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_personal_data`
--

LOCK TABLES `user_personal_data` WRITE;
/*!40000 ALTER TABLE `user_personal_data` DISABLE KEYS */;
INSERT INTO `user_personal_data` VALUES (2,'Laura','van de soms','Helgering',0,'laura_helgering@hotmail.com','612345678','687654321','1994-01-25','Hoi, ik ben laura :)',2012),(4,'Bas',NULL,'Nachtegaal',1,'bas@nachtegaal.eu','0031641688333',NULL,'1984-10-11','participating at website building course, like a boss!',NULL),(6,'Super',NULL,'Tim',1,'asdf@live.nl','0612345678','0612345678','1992-06-16','Ik ben een blije student! Ik heet Tim en ben heel vriendelijk tegen insecten. Daarom dus ook extra goed in biologie!',NULL),(10,'Berend','de ','Bolle Bijlesdocent',1,'berend@bol.com','0612345678','0693969395\r\n','1992-06-16','Ik ben op dezelfde dag jarig als Super Tim! Is dat niet grappig. Verder is er weinig over mij te weten behalve dus dat ik een superbe bijlesdocent ben! Hahahha hah ahh ahha ha aaaaaah ha :) :D',NULL),(3,'Hester','van','Trommel',0,'hes@trom.nl','0612345678','0698765432','2013-01-09','Ik ben Hester en ik studeer Pyschologie. Ik woon samen met twee supercoole huisgenoten :D',1234),(11,'Hester','van','Trommel',0,'hes@trom.nl','0612345678','0698765432','2013-01-09','Ik ben Hester en ik studeer Pyschologie. Ik woon samen met twee supercoole huisgenoten :D',NULL),(0,'Alexander','van ','Someren',1,'alexanderensomeren@someren.nl',NULL,'0612345678','2013-01-31','Hallo ik ben Alexander van Someren. Ik ga in de zomer op vakantie en ga dan veel van de muziek die nu ook op staat spelen.',2013),(43,'Salt','van','Peperen',0,'salt@pepper.com','0634523432','','1965-01-01','Nee niet echt, ballalalbn',NULL),(68,'Boris','de','Polski',1,'bdp@live.nl','0614563543','','1992-03-04','A^2 + B^2 = C^2!',NULL),(52,'Zoey','op \'t','Veldt',0,'Zotv@hotmail.com','0613245345','','1993-01-02','Hallo, ik ben Zoey!',NULL),(53,'Fieke','de','Wieke',0,'Fdewieke@live.nl','0613245678','0202345465','1991-01-02','Hallo ik ben Fieke de Wieke. Ik hou van paarden en bijles geven. Verder ben ik heel blij en vrolijk. Groetjes!!!!!!!!!!',NULL),(54,'Francine','','Olmenbos',0,'folmenbos@live.nl','0617384654','','1998-02-03','Hallo ik ben Francine. Ik geef graag bijles. Ik kan heel goed Scheikunde. Tot ziens!',NULL),(55,'Froukje','van','Franiken',0,'fffff@hotmail.com','0612345678','','1992-03-02','Nee, maar ik spreek goed Russisch.',NULL),(56,'Frits','de','Boer',1,'boerenfrits@live.nl','0203546575','','1992-01-03','Hallo ik ben Frits. Ik spreek talen uit Zuid-Europa. Frans, Italiaans en Spaans. Grieks spreek ik ook, maar niet zo goed. Adieu!',NULL),(57,'Willem','de','Vrolijke',1,'wdv@live.nl','0613254657','','1991-02-03','Hallo ik ben Willem. Weerwolf Willem',NULL),(58,'Willem','de','Vierde',1,'koningwillem@oranje.nl','0612312321','','1976-02-01','Hallo ik ben Willem de Vierde. Een koning met een baard.',NULL),(59,'Emma','van der','Velden',0,'evdv@gmail.com','0634523431','','1990-08-01','',NULL),(60,'Alex-Sander','van','Zomeren',1,'alxvz@gmail.com','0203457693','','1995-01-03','Ik geef heel veel bijles.',NULL),(61,'Gea','de','Boerin',0,'gedebe@live.nl','02013276856','','1992-03-01','Ik geef alleen bijles ana slimme mensne.',NULL),(62,'Halle','','Groenhart',1,'hallegroenhart@live.nl','0645673543','','1981-02-03','--',NULL),(63,'Olaf','van','Britsen',1,'ovbritsen@live.nl','0746547343','','1991-03-02','Ik ben Olaf de Polaf. Hallo hallo :)',NULL),(64,'Ik','ben','Kabouter Plop',1,'kbplopperdeplop@live.nl','0756476487','','1982-03-02','Ik hou van wiskunde. Plopperdeplop!',NULL),(66,'Reindert','','Kromhout',1,'rkromhout@live.nl','0623495876','','1982-04-01','Ik wil bijles GEVEN!!!!',NULL),(67,'Anneke','','Leunissen',0,'annekep@live.nl','0675465765','','1984-01-02','Ik spreek Nederlands. English I speak toooo',NULL),(74,'Laurens','de','Graaff',1,'ldgggg@live.nl','0656745645','','1984-03-02','Biopharmacie',NULL),(75,'Bert','en','Ernie',1,'bertenernie@sesamstraat.nl','02034554654','','1922-01-02','--',NULL),(73,'Wouter','de','Boskabouter',1,'wdboskabouter@live.nl','0675645634','','1999-01-02','Wiskunde',NULL),(76,'Griekje','uit','Griekenland',0,'grrr@live.nl','0614563543','','1998-02-03','Grieks is mijn passie.',NULL),(77,'Roger','','Overstegen',1,'roverstege@hotmai.com','0611223344','','1988-03-01','Ik geef heel wat bijles',NULL),(79,'Camille','van','Dinteren',0,'c.dint@jahoo.nl','0698765321','','1992-02-02','Ik heb weinig tot geen ervaring met bijles geven.',NULL),(80,'Ilse','van der','Linden',0,'ilse@hotmail.com','0612343234','','1991-04-01','Hallo ik ben Ilse',NULL);
/*!40000 ALTER TABLE `user_personal_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-02-01 23:42:49
